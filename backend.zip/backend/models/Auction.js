const mongoose = require('mongoose');

const auctionSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String },
    startingBid: { type: Number, required: true },
    endTime: { type: Date, required: true }
}, { timestamps: true });

module.exports = mongoose.model('Auction', auctionSchema);