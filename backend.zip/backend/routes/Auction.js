const express = require('express');
const router = express.Router();
const Auction = require('../models/auction'); 

// POST route to create an auction
router.post('/', async (req, res) => {
    try {
        const { title, description, startingBid, endTime } = req.body;

        if (!title || !startingBid || !endTime) {
            return res.status(400).json({ message: 'Missing required fields' });
        }

        const newAuction = new Auction({
            title,
            description,
            startingBid,
            endTime
        });

        await newAuction.save();
        res.status(201).json({ message: 'Auction created successfully', auction: newAuction });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

router.get('/', async (req, res) => {
    try {
        const auctions = await Auction.find();
        res.status(200).json(auctions);
    } catch (error) {
        res.status(500).json({ message: "Server error" });
    }
});

router.put('/:id', async (req, res) => {
    try {
        const auction = await Auction.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!auction) {
            return res.status(404).json({ message: "Auction not found" });
        }
        res.status(200).json({ message: "Auction updated successfully", auction });
    } catch (error) {
        res.status(500).json({ message: "Server error" });
    }
});

// Delete an auction by ID
router.delete('/:id', async (req, res) => {
    try {
        const auction = await Auction.findByIdAndDelete(req.params.id);
        if (!auction) {
            return res.status(404).json({ message: "Auction not found" });
        }
        res.status(200).json({ message: "Auction deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: "Server error" });
    }
});

module.exports = router;
